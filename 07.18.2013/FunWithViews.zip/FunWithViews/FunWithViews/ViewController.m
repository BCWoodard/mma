//
//  ViewController.m
//  FunWithViews
//
//  Created by Brad Woodard on 7/18/13.
//  Copyright (c) 2013 Brad Woodard. All rights reserved.
//

#import "ViewController.h"
#import "MyView.h"

@interface ViewController ()
{
    int         numberOfTouches;
    int         totalMatches;
    MyView      *firstSubview;
    MyView      *secondSubview;
}

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    for (UIView *subview in self.view.subviews) {
        if ([subview isKindOfClass:[MyView class]]) {
            MyView *myView = (MyView *)subview;
            myView.delegate = self;
        }
    }
    
    numberOfTouches = 0;
    totalMatches = 0;

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.

}



#pragma mark MatchDelegate

- (void)didChooseView:(MyView *)myView
{    
    // Count the first two touches
    if (numberOfTouches == 0) {
        firstSubview = myView;
        numberOfTouches++;
        
    } else if (numberOfTouches == 1) {
        secondSubview = myView;
        numberOfTouches++;
    }
  
    // Logic for calculating a match/mismatch
    if (numberOfTouches == 2) {
        if (firstSubview.tag == secondSubview.tag) // MATCH
        {
            //firstSubview.backgroundColor = [UIColor greenColor];
            firstSubview.alpha = 0.5f;
            //secondSubview.backgroundColor = [UIColor greenColor];
            secondSubview.alpha = 0.5f;
            
            // increment totalMatches by one
            totalMatches++;
            NSLog(@"Total matches: %i", totalMatches);
            
            /* if (totalMatches == 8) {
                for (MyView *subview in self.view.subviews) {
                    subview.backgroundColor = [UIColor blueColor];
            }
            */
            
        } else if ((firstSubview.tag == secondSubview.tag) && (totalMatches == 8)) {
            for (MyView *subview in self.view.subviews) {
                subview.backgroundColor = [UIColor blueColor];
            }
            
        } else if (firstSubview.tag != secondSubview.tag) {
            NSLog(@"Go UIView yourself!");
            numberOfTouches = 0;
        }
            
        // Reset # of touches so we can begin matching again
        numberOfTouches = 0;
        }
        
    /*
    else if ((numberOfTouches == 2) && (firstSubview.tag == secondSubview.tag) && (totalMatches == 8)) {
        for (MyView *subview in self.view.subviews) {
            subview.backgroundColor = [UIColor blueColor];
        }
    */

    }


@end
